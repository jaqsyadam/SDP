package patterns.prototype;

public interface Prototype<T> {
    T clone();
}